#include <iostream>

using namespace std;

int main()
{
    int num1;
    int num2;
    int Retrievenum1;
    int Retrievenum2;

    cout<<"Enter number 1: "<<endl;
    cin>>num1;
    cout<<"Enter number 2: "<<endl;
    cin>>num2;

    Retrievenum1 = num1;
    Retrievenum2 = num2;

    if(num1 = num1 / 1 && num1 >= 1)
    {
        cout<<"num1 is a natural number "<<endl;
    }
    else if(num1 = num1 <= 0)
    {
        cout<<"num1 is a whole number. Try again"<<endl;
        return main();
    }
    if(num2 = num2 / 1 && num2 >= 1)
    {
        cout<<"num2 is a natural number "<<endl;
    }
    else if(num2 = num2 <= 0)
    {
        cout<<"num2 is a whole number. Try again"<<endl;
        return main();
    }
    cout<<Retrievenum1 + Retrievenum2<<endl;
    system("pause");
}
