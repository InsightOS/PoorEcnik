#include <iostream>

using namespace std;

int main()
{
    int num1;
    int num2;
    cout<<"Enter a number" <<endl;
    cin>>num1;
    cout<<"Enter the second number: "<<endl;
    cin>>num2;
    while(num1 >= num2)
    {
        if (num1 != num2)
        {
            num1 -= num2;
        }
        else
        {
            num2 -= num1;
        }
        cout<<"HCF is "<<num1;
        return 0;
    }
}
