#include <iostream>

using namespace std;

int main()
{
    int num;
    int Multiplenum;
    cout<<"Enter a number: "<<endl;
    cin>>num;
    cout<<"Enter how many multiples of "<<num<<" you want"<<endl;
    cin>>Multiplenum;

    for(int i; i<=Multiplenum; i++)
    {
        cout<<num<<" * "<<i<<" = "<<num * i<<endl;
    }


}
