#include <iostream>

using namespace std;

int main()
{
    int num1;
    int reminder;
    int Receivenum1;
    int reverse = 0;
    cout << "Enter a key to check if palindrome or not: ";
    cin>>num1;
    cout<<"Checking if number is palindromic or not...."<<endl;
    Receivenum1 = num1;
    cout<<"Received number is "<<Receivenum1<<endl;
    while(num1 > 0)
    {
        // this code was taken from the reversing a number code.
        reminder = num1 % 10;
    	reverse = reverse * 10 + reminder;
    	num1 = num1 / 10;
    }
    if(Receivenum1 == reverse)
    {
        cout<<"The given number is palindromic! "<<endl;
        system("pause");
    }
    else
    {
        cout<<"the given number was not a palindromic number! Try again!"<<endl;
        return main();
    }

}
