#include <iostream>

using namespace std;

int main()
{
    int InputYear;

    cout<<"Enter a year: "<<endl;
    cin>>InputYear;
    if(InputYear % 4 == 0)
    {
        cout<<InputYear<<" was a leap year!"<<endl;
    }
    else
    {
        cout<<InputYear<<" was not a leap year!"<<endl;
    }
    system("pause");

}
