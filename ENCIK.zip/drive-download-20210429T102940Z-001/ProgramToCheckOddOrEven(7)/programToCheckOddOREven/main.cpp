#include <iostream>

using namespace std;

int main()
{
    int number;
    cout<<"Enter a number to check if even or odd"<<endl;
    cin>>number;
    cout<<"Checking if number is even or odd"<<endl;
    if(number % 2 == 0)
    {
        cout<<"its an even number"<<endl;
    }
    else
    {
        cout<<"its an odd number"<<endl;
    }

}
