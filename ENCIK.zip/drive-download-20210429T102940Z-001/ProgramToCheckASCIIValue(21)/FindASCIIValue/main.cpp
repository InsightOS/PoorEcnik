#include <iostream>

using namespace std;

int main()
{
    char char1;
    cout<<"enter a character to find ASCII value of: ";
    cin>>char1;
    cout<<"The ASCII value is "<<int(char1);
}
