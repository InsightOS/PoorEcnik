#include <iostream>

using namespace std;

int main()
{
    int num1;
    int num2;

    cout<<"enter num1"<<endl;
    cin>>num1;
    cout<<"enter num2"<<endl;
    cin>>num2;
    cout<<"Hence, "<<num1 / num2<<" is the Quotient of "<<num1<< " divided by "<<num2<<" and the remainder is "<<num1 % num2<<endl;
    system("pause");
}
