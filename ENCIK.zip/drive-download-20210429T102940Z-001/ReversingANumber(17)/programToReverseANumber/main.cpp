#include <iostream>

using namespace std;

int main()
{
    int num1;
    int reminder;
    int recievenum1;
    int reverse;
    cout<<"Enter a number to reverse: "<<endl;
    cin>>num1;
    recievenum1 = num1;
    cout<<"Reversing "<<num1<<" ....."<<endl;
    while(num1 > 0)
    {
        //this formula was found on the web and the code/implementation is by me.
        reminder = num1 % 10;
    	reverse = reverse * 10 + reminder;
    	num1 = num1 / 10;
    }

    cout<<"The reversed number of "<<recievenum1<<" is "<<reverse<<endl;
    system("pause");

}
