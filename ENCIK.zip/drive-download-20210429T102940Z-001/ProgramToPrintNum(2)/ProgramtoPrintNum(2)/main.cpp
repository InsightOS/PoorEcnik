#include <iostream>
#include<stdlib.h>
#include<conio.h>

using namespace std;

int main()
{
    string PrintNum;
    string Restart;
    cout<<"Enter your number"<<endl;
    getline(cin, PrintNum);
    cout<<"The number that has been pressed is "<<PrintNum<<endl;

    cout<<"want to restart? Y or N"<<endl;
    getline(cin, Restart);
    if(Restart == "Y")
    {
        return main();
    }
    if(Restart == "N")
    {
        return 0;
    }
}

