#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int num1;
    bool isprime = true;
    cout<<"Enter a number to check if Prime or not"<<endl;
    cin>>num1;
    if(num1 == 0 || num1 == 1)
    {
        isprime = false;
    }
    else
    {
        for(int i = 2; i<= num1 / 2; i++)
        {
            if(num1 % i == 0)
            {
                isprime = false;
                break;
            }
        }
    }
    if(isprime)
    {
        cout<<num1<<" is a prime number"<<endl;
    }
    else
    {
        cout<<num1<<" is not a prime number"<<endl;
    }
    system("pause");
}
