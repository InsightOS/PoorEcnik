#include <iostream>

using namespace std;

int main()
{
    int reminder;
    int num1;
    int Recivenum1Value;
    int reverse = 0;
    cout<<"Enter a number to reverse"<<endl;
    cin>>num1;
    Recivenum1Value = num1;
    while(num1 > 0)
    {
        reminder = num1 % 10;
    	reverse = reverse * 10 + reminder;
    	num1 = num1 / 10;
    }
    cout<<"The reverse of "<<Recivenum1Value<<" is "<<reverse<<endl;
    system("pause");
}
