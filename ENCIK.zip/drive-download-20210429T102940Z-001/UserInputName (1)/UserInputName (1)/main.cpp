#include <iostream>
#include <stdlib.h>
#include <stdio.h>


using namespace std;


int main()
{
    string YesORNo;
    string Name;
    cout<<"Enter your name"<<endl;
    getline(cin, Name);
    cout<<"Thanks for the info!, Your name is "<<Name<< " right? Y or N? (CAPITAL ONLY)"<<endl;
    getline(cin, YesORNo);
    if(YesORNo ==  "Y")
    {
        cout<<"Congratz! The name is saved correctly!"<<endl;
        system("pause");
    }
    if(YesORNo == "N")
    {
        cout<<"OH! enter your name again!"<<endl;
        return main();
    }




}





