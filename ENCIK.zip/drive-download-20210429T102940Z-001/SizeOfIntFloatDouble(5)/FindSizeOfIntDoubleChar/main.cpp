#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    cout<<"The size of int is "<<sizeof(int)<<endl;
    cout<<"The size of float is "<<sizeof(float)<<endl;
    cout<<"The size of char is "<<sizeof(char)<<endl;
    cout<<"The size of double is "<<sizeof(double)<<endl;
    cout<<"The size of string is "<<sizeof(string)<<endl;
    system("pause");
}
