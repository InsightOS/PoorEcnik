#include <iostream>

using namespace std;


int main()
{
    int num1;
    int num2;
    int SwappedInt1;
    int SwappedInt2;
    string YN;

    cout<<"Enter a number = "<<endl;
    cin>>num1;
    cout<<"Enter the second number = "<<endl;
    cin>>num2;

    cout<<"Hence, num1 is "<<num1<<" and num2 is "<<num2<<endl;
    SwappedInt2 = num2;
    SwappedInt1 = num1;
    cout<<"Are you ready to swap both these numbers? Y OR N (CAPITAL ONLY)"<<endl;
    cin>>YN;
    if(YN == "Y")
    {
        SwappedInt2 = num1;
        SwappedInt1 = num2;
        cout<<"Hence num1 is "<<SwappedInt1<< " and num2 is "<<SwappedInt2<<endl;
        system("pause");
    }
    if(YN == "N")
    {
        cout<<"process window killed successfully!"<<endl;
        system("pause");
    }

}
