#include <iostream>
#include <graphics.h>

using namespace std;

int main()
{
    for(int i = 1; i<=5; i++)
    {
        cout<<" *"<<endl;
        for
    }
}
