#include <iostream>

using namespace std;

int main()
{

    int num1;
    int num2;

    cout<<"enter number one: "<<endl;
    cin>>num1;
    cout<<"Enter number two: "<<endl;
    cin>>num2;
    cout<<" answer is "<<num1 + num2<<endl;
    system("pause");

    //Sir I had made better code than this (its below) but for some reason it didn't give the answer
    // can you please check for error because everything looks correct.
    // had implemented a system that sees if a number is true or false. didn't work. please check formula and why its not working.

    /*
    int num1;
    int num2;
    cout<<"Enter your first number: "<<endl;
    cin>>num1;
    cout<<"Checking if entered number is a number or anything else.........."<<endl;
    if(num1 = num1 / 1 || num1 == 0)
    {
        cout<<"The given number is a number."<<endl;
    }

    else
    {
        cout<<"The given number is NOT a number. Try again"<<endl;
        return main();
    }
    cout<<"Enter the second number: ";
    cin>>num2;
    cout<<"Checking if entered number is a number or anything else.........."<<endl;
    if(num2 = num2 / 1 || num2 == 0)
    {
        cout<<"The given number is a number."<<endl;
    }

    else
    {
        cout<<"The given number is NOT a number. Try again"<<endl;
        return main();
    }
    cout<<"Adding the following numbers: "<<endl;
    cout<<num1 + num2<<endl;

      */



}
