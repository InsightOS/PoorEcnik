#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int powcalc;
    int num1;
    cout<<"Enter a number to calculate the power of: "<<endl;
    cin>>num1;
    powcalc = num1;

    cout<<"The square root of "<<num1<< " is "<<sqrt(powcalc)<<" Hence, power is "<<sqrt(powcalc)<<" raised to "<<sqrt(powcalc)<<endl;
    system("pause");


}
