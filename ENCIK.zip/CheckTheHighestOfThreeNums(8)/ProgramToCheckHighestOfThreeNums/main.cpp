#include <iostream>

using namespace std;

int main()
{
   float num1;
   float num2;
   float num3;
   int ResultOfTheThreeNumbersByComparison;
   cout<<"Enter your first number: ";
   cin>>num1;
   cout<<"Enter your second number: ";
   cin>>num2;
   cout<<"Enter your third number: ";
   cin>>num3;
   cout<<"Calculating which is the greatest of all"<<endl;
   if(num1 >= num2 && num1 >= num3)
   {
      ResultOfTheThreeNumbersByComparison = num1;
      cout<<"answer is "<<ResultOfTheThreeNumbersByComparison<<endl;
   }
   else if(num2 >= num1 && num2 >= num3)
   {
      ResultOfTheThreeNumbersByComparison = num2;
      cout<<"answer is "<<ResultOfTheThreeNumbersByComparison<<endl;
   }
   else
   {
       ResultOfTheThreeNumbersByComparison = num3;
       cout<<"answer is "<<ResultOfTheThreeNumbersByComparison<<endl;
   }

   system("pause");



}

